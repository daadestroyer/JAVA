package com.prog5.springcore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prog5Application {

	public static void main(String[] args) {
		SpringApplication.run(Prog5Application.class, args);
	}

}
