package com.prog5.springcore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prog5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
