package prog1;

import java.util.*;

class GFG {

// Method to find number of sticks by breaking them
	static int sticks_break(int stick_length, int n, int desired_length) {

		// If stick cant be break any more
		if (n < 1)
			return 0;

		// Check if stick length became
		// smaller than the desired length
		if (stick_length < desired_length)
			return 0;

		// Check if stick length is even number
		if (stick_length % 2 == 0)

			// Check if half of stick
			// length is equal to desired length
			if (stick_length / 2 == desired_length)
				return 2;

			// Check if half of stick length
			// is greater than the desired length
			else if (stick_length / 2 > desired_length)
				return (sticks_break(stick_length / 2, n - 1, desired_length));

		// Check if stick length is odd number
		if (stick_length % 2 != 0)

			// For odd number two halves will be
			// generated checking if first half
			// is equal to desired length
			if (stick_length / 2 == desired_length)
				return 1;

		// Checking if second half
		// is equal to desired length
		if (stick_length / 2 + 1 == desired_length)
			return 1;

		// Check if half of stick length
		// is greater than the desired length
		if (stick_length / 2 > desired_length)
			return (Math.max(sticks_break(stick_length / 2, n - 1, desired_length),
					sticks_break(stick_length / 2 + 1, n - 1, desired_length)));

		return 0;
	}

// Method to find number of sticks
	static int numberOfSticks(int list_length[], int n, int desired_length) {
		int count = 0;

		for (int i = 0; i < list_length.length; i++) {

			// Check if desired length is found
			if (desired_length == list_length[i])

				// Incrementing the count
				count = count + 1;

			// Check if stick length is
			// greater than desired length
			else if (list_length[i] > desired_length)

				// Incrementing count
				// after break the sticks
				count = count + sticks_break(list_length[i], n, desired_length);
		}

		// Return count
		return count;
	}

// Driver code
	public static void main(String args[]) {

		// List of integers
		int[] list_length = new int[] { 1, 6, 2, 3 ,4 };

		// Number of ways stick can be break
		int n = list_length.length;

		// Desired length
		int desired_length = 3;

		int count = numberOfSticks(list_length, n, desired_length);

		// Print result
		System.out.println(count);
	}
}

// This code is contributed by Stream_Cipher
