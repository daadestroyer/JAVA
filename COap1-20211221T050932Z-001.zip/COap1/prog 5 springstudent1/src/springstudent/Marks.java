package springstudent;

public class Marks {
int intno;
int test1,test2,test3,ass1, ass2, quiz1,quiz2,totalmarks;
public int getIntno() {
return intno;
}
public void setIntno(int intno) {
this.intno = intno;
}
public int getTest1() {
return test1;
}
public void setTest1(int test1) {
this.test1 = test1;
}
public int getTest2() {
return test2;
}
public void setTest2(int test2) {
this.test2 = test2;
}
public int getTest3() {
return test3;
}
public void setTest3(int test3) {
this.test3 = test3;
}
public int getAss1() {
return ass1;
}
public void setAss1(int ass1) {
this.ass1 = ass1;
}
public int getAss2() {
return ass2;
}
public void setAss2(int ass2) {
this.ass2 = ass2;
}
public int getQuiz1() {
return quiz1;
}
public void setQuiz1(int quiz1) {
this.quiz1 = quiz1;
}
public int getQuiz2() {
return quiz2;
}
public void setQuiz2(int quiz2) {
this.quiz2 = quiz2;
}
public int getTotalmarks() {
return totalmarks;
}
public void setTotalmarks(int totalmarks) {
this.totalmarks = totalmarks;
}
public int Calculate() {
// TODO Auto-generated method stub
int cal = (test1+test2+test3)/3+(quiz1+quiz2)+(ass1+ass2);
return cal;
}
}