package springstudent;

import java.util.Scanner;
import org.springframework.context.ApplicationContext;

import org.springframework.context.support.ClassPathXmlApplicationContext;
public class StudMark_Main {
	public static void main(String[] args) {
	
	ApplicationContext ac = new	ClassPathXmlApplicationContext("Beans_Config.xml");
	Student s = ac.getBean("student",Student.class);
	Marks m = ac.getBean("marks", Marks.class);
	System.out.println("Enter the Student Details: ");
	System.out.println("Enter the student usn");
	Scanner sc = new Scanner(System.in);
	//s.setUsn(sc.next());
	System.out.println("Enter the student name");
//	s.setName(sc.next());
	System.out.println("Enter the student semester");
	//s.setSemester(sc.nextInt());
	System.out.println("Enter the Student Marks: ");
	System.out.println("Enter the Test 1");
	m.setTest1(sc.nextInt());
	System.out.println("Enter the Test 2");
	m.setTest2(sc.nextInt());
	System.out.println("Enter the Test 3");
	m.setTest3(sc.nextInt());
	System.out.println("Enter the Assignment 1");
	m.setAss1(sc.nextInt());
	System.out.println("Enter the Assignment 2");
	m.setAss2(sc.nextInt());
	System.out.println("Enter the Quiz 1");
	m.setQuiz1(sc.nextInt());
	System.out.println("Enter the Quiz 2");
	m.setQuiz2(sc.nextInt());
 	System.out.println(s.toString());
	

	}
}