package springstudent;

public class Student {
String usn, name;
int semester;
Marks marks;
public String getUsn() {
return usn;
}
public void setUsn(String usn) {
this.usn = usn;
}
public String getName() {
return name;
}
public void setName(String name) {
this.name = name;
}
public int getSemester() {
return semester;
}
public void setSemester(int semester) {
this.semester = semester;
}
public Marks getMarks() {
return marks;
}
public void setMarks(Marks marks) {
this.marks = marks;
}
@Override
public String toString() {
return "Student [usn=" + usn + ", name=" + name + ", semester=" + semester + ", "
+ "\nTest1=" + marks.getTest1() +
"\nTest2=" + marks.getTest2() +
"\nTest3=" + marks.getTest3() +
"\nAssignment 1=" + marks.getAss1() +
"\nAssignment 2=" + marks.getAss2() +
"\nQuiz 1=" + marks.getQuiz1() +
"\nQuiz 2=" + marks.getQuiz2() +
"\nTotal Marks =" + marks.Calculate() +
"]";
}
}