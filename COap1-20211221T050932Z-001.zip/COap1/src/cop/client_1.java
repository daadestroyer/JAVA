package cop;

import java.io.IOException;

import org.eclipse.californium.core.CoapClient;
import org.eclipse.californium.elements.exception.ConnectorException;

public class client_1 {
public static void main(String args[]) {
	CoapClient c=new CoapClient("coap://localhost/hello");
	try {
		for(int i=0;i<10;i++) {
			
		
		String s=c.get().getResponseText();
		System.out.println(s);
		}
	} catch (ConnectorException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
