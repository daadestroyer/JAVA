package cop;

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.CoapServer;
import org.eclipse.californium.core.server.resources.CoapExchange;

public class server_1 extends CoapResource{

	public server_1(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
@Override
public void handleGET(CoapExchange exchange) {
	// TODO Auto-generated method stub
	String s1="hello";
	exchange.respond(s1);
	System.out.println(s1);
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO: handle exception
		e.printStackTrace();
	}
}
public static void main(String args[])
{
	CoapServer s=new CoapServer();
	s.add(new server_1("hello"));
	s.start();
}
}
