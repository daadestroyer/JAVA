package com.rvce.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
 
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.rvce.model.ProductModel;

@Controller
public class MainController {

	@RequestMapping("/")
	public String index(Model model) {
		model.addAttribute("productModel",new ProductModel());
		System.out.println("index");
		return "index";
	}

	@RequestMapping("/action")
	public String action(@ModelAttribute("productModel") ProductModel productModel , Model model) {
		model.addAttribute("pid",productModel.getPid());
		model.addAttribute("pname",productModel.getPname());
		model.addAttribute("pprice",productModel.getPprice());
		model.addAttribute("pdesc",productModel.getPdesc());
		model.addAttribute("pcomp",productModel.getPdesc());
		 return "display";
	}
}
