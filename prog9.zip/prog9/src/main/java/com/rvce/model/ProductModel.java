package com.rvce.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class ProductModel {

	@NotNull
	@Size(min = 3 , max = 5 , message = "pid cant be empty")
	private String pid;
	private String pname;
	private String pprice;
	private String pdesc;
	private String pcomp;

	public ProductModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPprice() {
		return pprice;
	}

	public void setPprice(String pprice) {
		this.pprice = pprice;
	}

	public String getPdesc() {
		return pdesc;
	}

	public void setPdesc(String pdesc) {
		this.pdesc = pdesc;
	}

	public String getPcomp() {
		return pcomp;
	}

	public void setPcomp(String pcomp) {
		this.pcomp = pcomp;
	}

	public ProductModel(String pid, String pname, String pprice, String pdesc, String pcomp) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.pprice = pprice;
		this.pdesc = pdesc;
		this.pcomp = pcomp;
	}

	@Override
	public String toString() {
		return "ProductModel [pid=" + pid + ", pname=" + pname + ", pprice=" + pprice + ", pdesc=" + pdesc + ", pcomp="
				+ pcomp + "]";
	}

}
