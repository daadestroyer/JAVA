package com.rvce.message;

public class Message {
	private String pidMessage;
	private String pNameMessage;
	private String pPriceMessage;
	private String pDescMessage;
	private String pCompanyMessage;
	
	
	public Message() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Message(String pidMessage, String pNameMessage, String pPriceMessage, String pDescMessage,
			String pCompanyMessage) {
		super();
		this.pidMessage = pidMessage;
		this.pNameMessage = pNameMessage;
		this.pPriceMessage = pPriceMessage;
		this.pDescMessage = pDescMessage;
		this.pCompanyMessage = pCompanyMessage;
	}


	public String getPidMessage() {
		return pidMessage;
	}


	public void setPidMessage(String pidMessage) {
		this.pidMessage = pidMessage;
	}


	public String getpNameMessage() {
		return pNameMessage;
	}


	public void setpNameMessage(String pNameMessage) {
		this.pNameMessage = pNameMessage;
	}


	public String getpPriceMessage() {
		return pPriceMessage;
	}


	public void setpPriceMessage(String pPriceMessage) {
		this.pPriceMessage = pPriceMessage;
	}


	public String getpDescMessage() {
		return pDescMessage;
	}


	public void setpDescMessage(String pDescMessage) {
		this.pDescMessage = pDescMessage;
	}


	public String getpCompanyMessage() {
		return pCompanyMessage;
	}


	public void setpCompanyMessage(String pCompanyMessage) {
		this.pCompanyMessage = pCompanyMessage;
	}
	
	
}
