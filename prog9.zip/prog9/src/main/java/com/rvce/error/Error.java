package com.rvce.error;

public class Error {

	private String messageString;
	
	
	
}
